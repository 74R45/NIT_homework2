console.log(`The time is ${new Date()}`);
import './scss/main.scss';
import 'bootstrap';